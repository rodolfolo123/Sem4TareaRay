package maps;
  public class coordenadas{
    public double lat;
    public double lonj;
  }